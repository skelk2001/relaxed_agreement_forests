To compile this you need JavaCC (the Java Compiler Compiler) and the ability to compile .java files.

Compilation is simple:

$ javacc ExtractQuartets.jj

$ javac ExtractQuartets.java

You can type java ExtractQuartets -help to get (brief) information on running the code. Please pay attention to the
text about the -n flag! The short version is this: if your taxa are already 1..n, don't specify the -n flag. If they
are not, do.

The basic idea is that you feed the code a file containing two trees, in Newick format, and it extracts the
incompatible quartets i.e. those size-4 subsets that induce different topologies in the two input trees. The code
treats the trees as unrooted, whether or not you include a root in the Newick.

The output is designed to be used as a data file (.dzn) for the MiniZinc files (.mzn) elsewhere in the package. The
MiniZinc files assume that the quartets are in the file 'quartets.dzn' so typically you will send the output from
ExtractQuartets to this file.

Here's a simple example of using the code.

Consider the file exampleTree.txt:

$ cat exampleTree.txt

(a,(b,(c,(d,e))));
(e,(b,(c,(d,a))));

Here is what you should see if you run the code:

$ java ExtractQuartets -n < exampleTree.txt

% Leaf 'a' gets internal number 1
% Leaf 'b' gets internal number 2
% Leaf 'c' gets internal number 3
% Leaf 'd' gets internal number 4
% Leaf 'e' gets internal number 5
% Taxa in tree 1: 5
% Taxa in tree 2: 5
n = 5;
numq = 5;
quartets = array2d(1..numq, 1..4, [
1, 2, 3, 4,
1, 2, 3, 5,
1, 2, 4, 5,
1, 3, 4, 5,
2, 3, 4, 5
]);

Note how the taxa have been relabelled to 1..n, which is required by the MiniZinc files. The mapping from
the original taxa labels into 1..n is stated at the top of the output file.


Cheers,

Steven Kelk
August 2023
