Before you run these MiniZinc .mzn files, you need to first generate a set of incompatible quartets
using the ExtractQuartets java code in the other folder.

The .mzn MiniZinc files assume that these quartets are in the file 'quartets.dzn'.

* ComputeMRAF.mzn

As the name suggests, it computes a MRAF!

* ComputeMAST.mzn

There are polynomial-time algorithms for computing a MAST, but this constraint-programming based formulation
runs reasonably quickly and is useful for testing hypotheses about MASTs.

Some important notes:

1. MiniZinc ships with multiple different solvers under the hood. These have different strengths and weaknesses.
For most of the work in this article we used the back-end solver Chuffed which ships with MiniZinc as standard.

2. These are optimization MiniZinc models. Once you have computed the optimum, you can hard-code this back in as
a constraint, switch to a decision model (solve satisfy) and then ask solvers such as Chuffed and Geocode to generate
-all- satisfying solutions. (This is not a standard setting, so you will need to switch it on yourself). This then generates truly -all- optimal solutions, which can yield valuable information
and help with computational proofs.

The file ComputeMAST_all_sols.mzn is an example of how to do this. (Here, the size of the MAST has been hard-coded to
4, you should obviously change it if that is not the size of the MAST). The decision model tests whether there
is an agreement subtree of size exactly 4. If you then activate the 'all solutions' flag, it will return
all agreement subtrees of size exactly 4.
