Below we see that (MRAF-1) does not obey the triangle inequality. The file tri1_2.txt contains T1 and T2,
the file tri1_3.txt contains T1 and T3, and tri3_2.txt contains T3 and T2.

====

skelk@LAPTOP-MQDFLHTJ:/mnt/c/Users/steve/Downloads/mraf/dmp_sampling_bound_code$ cat tri1_2.txt
(c1,((x1,(1,a1)),(b1,(c2,((x2,(2,a2)),(b2,(c3,((x3,(3,a3)),(b3,(c4,((x4,(4,a4)),b4)))))))))));
((2,x2),((c2,b2),(a2,((1,x1),((c1,b1),(a1,((4,x4),((c4,b4),(a4,((3,x3),((c3,b3),a3)))))))))));

skelk@LAPTOP-MQDFLHTJ:/mnt/c/Users/steve/Downloads/mraf/dmp_sampling_bound_code$ cat tri1_3.txt
(c1,((x1,(1,a1)),(b1,(c2,((x2,(2,a2)),(b2,(c3,((x3,(3,a3)),(b3,(c4,((x4,(4,a4)),b4)))))))))));
(c2,((x2,(2,a2)),(b2,(c1,((x1,(1,a1)),(b1,(c4,((x4,(4,a4)),(b4,(c3,((x3,(3,a3)),b3)))))))))));

skelk@LAPTOP-MQDFLHTJ:/mnt/c/Users/steve/Downloads/mraf/dmp_sampling_bound_code$ cat tri3_2.txt
(c2,((x2,(2,a2)),(b2,(c1,((x1,(1,a1)),(b1,(c4,((x4,(4,a4)),(b4,(c3,((x3,(3,a3)),b3)))))))))));
((2,x2),((c2,b2),(a2,((1,x1),((c1,b1),(a1,((4,x4),((c4,b4),(a4,((3,x3),((c3,b3),a3)))))))))));

skelk@LAPTOP-MQDFLHTJ:/mnt/c/Users/steve/Downloads/mraf/dmp_sampling_bound_code$ java ExtractQuartets -n < tri1_2.txt > quartets.dzn
skelk@LAPTOP-MQDFLHTJ:/mnt/c/Users/steve/Downloads/mraf/dmp_sampling_bound_code$ ./minizinc.exe ComputeMRAF.mzn --solver Chuffed
4
[2, 4, 4, 2, 4, 2, 2, 2, 1, 1, 3, 3, 3, 4, 4, 3, 1, 1, 3, 1]
----------
==========
% [target > 3]
skelk@LAPTOP-MQDFLHTJ:/mnt/c/Users/steve/Downloads/mraf/dmp_sampling_bound_code$ java ExtractQuartets -n < tri1_3.txt > quartets.dzn
skelk@LAPTOP-MQDFLHTJ:/mnt/c/Users/steve/Downloads/mraf/dmp_sampling_bound_code$ ./minizinc.exe ComputeMRAF.mzn --solver Chuffed
2
[1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2]
----------
==========
% [target > 1]
skelk@LAPTOP-MQDFLHTJ:/mnt/c/Users/steve/Downloads/mraf/dmp_sampling_bound_code$ java ExtractQuartets -n < tri3_2.txt > quartets.dzn
skelk@LAPTOP-MQDFLHTJ:/mnt/c/Users/steve/Downloads/mraf/dmp_sampling_bound_code$ ./minizinc.exe ComputeMRAF.mzn --solver Chuffed
2
[2, 2, 2, 1, 1, 1, 2, 2, 1, 2, 1, 2, 2, 1, 2, 1, 1, 1, 2, 2]
----------
==========
% [target > 1]
